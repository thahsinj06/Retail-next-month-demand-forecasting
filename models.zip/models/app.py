import streamlit as st
import pandas as pd
import joblib
import os
from datetime import datetime
import calendar


# ==========================================
# LOAD MODEL FILES
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(
    BASE_DIR,
    "smartretail_random_forest.pkl"
)

PREPROCESSOR_PATH = os.path.join(
    BASE_DIR,
    "smartretail_preprocessor.pkl"
)

model = joblib.load(MODEL_PATH)
preprocessor = joblib.load(PREPROCESSOR_PATH)


# ==========================================
# PAGE CONFIGURATION
# ==========================================

st.set_page_config(
    page_title="SmartRetail Demand Predictor",
    page_icon="📊",
    layout="centered"
)


# ==========================================
# HEADER
# ==========================================

st.title("📊 SmartRetail Demand Predictor")

st.write(
    "Predict the expected demand for a product during the next month "
    "using current retail conditions."
)

st.divider()


# ==========================================
# INPUTS
# ==========================================

st.subheader("Enter Current Retail Conditions")

# Row 1
col1, col2, col3 = st.columns(3)

with col1:
    product_id = st.selectbox(
        "Product ID",
        ["P001", "P002", "P003", "P004", "P005"]
    )

with col2:
    product_category = st.selectbox(
        "Product Category",
        [
            "Electronics",
            "Groceries",
            "Fashion",
            "Home Appliances",
            "Personal Care"
        ]
    )

with col3:
    city = st.selectbox(
        "City",
        [
            "Kochi",
            "Delhi",
            "Mumbai",
            "Pune",
            "Bangalore"
        ]
    )


# Row 2
col1, col2, col3 = st.columns(3)

with col1:
    store_type = st.selectbox(
        "Store Type",
        ["Mall", "Neighbourhood", "Supermarket"]
    )

with col2:
    price = st.number_input(
        "Product Price (₹)",
        min_value=1.0,
        value=1500.0,
        step=100.0
    )

with col3:
    discount = st.slider(
        "Discount (%)",
        min_value=0,
        max_value=50,
        value=10
    )


# Row 3
col1, col2, col3 = st.columns(3)

with col1:
    marketing_spend = st.number_input(
        "Marketing Spend (₹)",
        min_value=0.0,
        value=20000.0,
        step=1000.0
    )

with col2:
    holiday_flag = st.selectbox(
        "Holiday / Festival",
        ["Yes", "No"]
    )

with col3:
    previous_demand = st.number_input(
        "Previous Month Demand",
        min_value=0,
        value=800,
        step=50
    )


# Row 4
col1, col2, col3 = st.columns(3)

with col1:
    season = st.selectbox(
        "Season",
        ["Summer", "Monsoon", "Winter", "Festival"]
    )

# ==========================================
# AUTOMATIC FEATURES
# ==========================================

current_date = datetime.now()

year = current_date.year
month = current_date.month
quarter = (month - 1) // 3 + 1

# Calculate discounted price automatically
discounted_price = price * (1 - discount / 100)

# Calculate next month
if month == 12:
    next_month = 1
    next_year = year + 1
else:
    next_month = month + 1
    next_year = year

next_month_name = calendar.month_name[next_month]


# ==========================================
# PREDICTION BUTTON
# ==========================================

if st.button(
    "🔮 Predict Next Month Demand",
    use_container_width=True
):

    # Create input dataframe
    input_data = pd.DataFrame([{
        "Product_ID": product_id,
        "Product_Category": product_category,
        "City": city,
        "Store_Type": store_type,
        "Price": price,
        "Discount_Percentage": discount,
        "Marketing_Spend": marketing_spend,
        "Holiday_Flag": holiday_flag,
        "Previous_Month_Demand": previous_demand,
        "Season": season,
        "Year": year,
        "Month": month,
        "Quarter": quarter,
        "Discounted_Price": discounted_price
    }])

    # Apply training preprocessing
    input_processed = preprocessor.transform(input_data)

    # Generate prediction
    prediction = model.predict(input_processed)[0]

    prediction = round(prediction)


    # ======================================
    # DISPLAY RESULT
    # ======================================

    st.divider()

    st.subheader("📦 Prediction Result")

    st.success(
        f"Expected Demand for {next_month_name} {next_year}: "
        f"**{prediction} units**"
    )

    st.write(
        f"The model predicts approximately **{prediction} units** "
        f"of demand for the following month."
    )


    # ======================================
    # BUSINESS VALUE
    # ======================================

    st.info(
        "💡 This prediction can support inventory planning, "
        "procurement, and stock allocation."
    )


# ==========================================
# FOOTER
# ==========================================

st.divider()

st.caption(
    "SmartRetail India | Machine Learning Demand Forecasting"
)